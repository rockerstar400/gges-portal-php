<?php 
include("header.php"); 

if(isset($_SESSION[PRE_FIX.'id']))
{
    echo "<script>window.location='dashboard.php?p=users'</script>";
}
?>



<div>
    <div class="login-page login-form-fall">

        <div class="login-container">
            <!-- <div class="login-header login-caret">
                <div class="login-content">
                    <a href="#" class="logo">
                        <img src="frontend_public/uploads/attachment/logo.png?time=<?php echo time(); ?>" width="220" alt="site-logo"/>
                    </a>
                </div>
            </div> -->
            <div class="login-header" style="text-align: center; padding-top: 20px;">
    <div class="login-content">
        <a href="#" class="logo" style="display: inline-block;">
            <!-- Yeh niche wala div image ko perfect circle mein kaat dega -->
            <!-- <div style="width: 140px; height: 140px; border-radius: 50%; overflow: hidden; background-color: #fff; display: flex; align-items: center; justify-content: center; margin: 0 auto;">
                <img src="frontend_public/uploads/attachment/logo.png?time=<?php echo time(); ?>" 
                     style="width: 115%; height: 115%; object-fit: cover; transform: scale(1.1); display: block;" 
                     alt="site-logo"/>
            </div> -->
        </a>
    </div>
</div>

            <div class="login-form">
                <div class="login-content">

                    <p style="color: #000;" id="error_message">
                          <?php
                          
                          /*
                          * sucess message custom
                          *
                          * */
                          
                          $error = [
                              1 => "Invalid Email Or Password",
                          ];
                          
                          $error_id = isset($_GET['error']);
                          if ($error != 0 && in_array($error_id, $error)) {
                                echo $error[$error_id];
                          }
                          ?>
                    </p>

                    <form method="POST" action="index.php?p=login" accept-charset="UTF-8" class="validate">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="entypo-user"></i>
                                </div>
                                <input class="form-control" placeholder="Email Address" autocomplete="off" name="email" type="email">
                            </div>
                            <small class='ve-error'></small>
                        </div>

                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <i class="entypo-key"></i>
                                </div>
                                <input class="form-control" data-validate="required" placeholder="Password" autocomplete="off" name="password" type="password" value="">
                            </div>
                            <small class='ve-error'></small>
                        </div>

                        <div class="form-group">
<button type="submit" name="login_btn" class="btn btn-block btn-login" style="background-color: #f37021 !important; border-color: #007bff !important; color: #ffffff !important; opacity: 1 !important;">
    Log In
    <i class="entypo-login" style="color: #ffffff !important;"></i>
</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
      
<?php 

include("footer.php"); 


?>

