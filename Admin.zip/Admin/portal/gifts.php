<?php 
if(isset($_SESSION[PRE_FIX.'id']))
{       
    
        
        $url=$baseurl . 'showGifts';
        $data =array();
        
        $json_data=@curl_request($data,$url);
        ?>

        <div class="qr-content">
            <div class="qr-page-content">
                <div class="qr-page zeropadding">
                    <div class="qr-content-area">
                        <div class="qr-row">
                            <div class="qr-el">

                                <div class="page-title">
                                    <h2>All Gifts</h2>
                                    <div class="head-area">
                                    </div>
                                </div>
                                
                                <div class="right" style="padding: 10px 0;">
                                    <button onclick="addGifts();" class="com-button com-submit-button com-button--large com-button--default" style="background-color: #f37021 !important; border: none !important; border-radius: 5px; cursor: pointer;">
                                        <!-- <div class="com-submit-button__content"><span>Add Gifts</span></div> -->
                                         <div class="com-submit-button__content">

            <span style="color: #ffffff !important; font-weight: bold;">Add Gifts</span>

        </div>
                                    </button>
                                </div>
                                <!--start of datatable here-->


                                <table id="table_view" class="display" style="width:100%">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Image</th>
                                            <th>Sound</th>
                                            <th>Time</th>
                                            <th>Icon</th>
                                            <th>Coin</th>
                                            <th>Featured</th>
                                            <th>Created</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <?php 
                                        if(is_array($json_data['msg']) || is_object($json_data['msg']))
                                        {
                                            foreach ($json_data['msg'] as $singleRow): 
                                                   
                                                ?>
                                                    <tr>
                                                        <td><?php echo $singleRow['Gift']['id']; ?></td>
                                                        <td>
                                                            <?php echo $singleRow['Gift']['title']; ?>
                                                        </td>
                                                        <td>
                                                           <a href="<?php echo checkVideoUrl($singleRow['Gift']['image']); ?>" target="_blank">View Attachment</a>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                if($singleRow['Gift']['sound']!="")
                                                                {
                                                                    ?>
                                                                        <a href="<?php echo checkVideoUrl($singleRow['Gift']['sound']); ?>" target="_blank">View Sound</a>
                                                                    <?php
                                                                }
                                                            ?>
                                                        </td>
                                                        <td>
                                                           <?php echo $singleRow['Gift']['time']; ?>
                                                        </td>
                                                        <td>
                                                            <?php
                                                                if($singleRow['Gift']['icon']!="")
                                                                {
                                                                    ?>
                                                                        <a href="<?php echo checkVideoUrl($singleRow['Gift']['icon']); ?>" target="_blank">View Icon</a>
                                                                    <?php
                                                                }
                                                            ?>
                                                        </td>
                                                        <td>
                                                           <?php echo $singleRow['Gift']['coin']; ?>
                                                        </td>
                                                        <td>
                                                           <?php
                                                                if($singleRow['Gift']['featured']=="1")
                                                                {
                                                                    echo "Yes";
                                                                }
                                                           ?>
                                                        </td>
                                                        <td>
                                                           <?php echo $singleRow['Gift']['created']; ?>
                                                        </td>
                                                        <td>
                                                            <div class="more">
                                                                <button id="more-btn" class="more-btn">
                                                                    <span class="more-dot"></span>
                                                                    <span class="more-dot"></span>
                                                                    <span class="more-dot"></span>
                                                                </button>
                                                                <div class="more-menu">
                                                                    <div class="more-menu-caret">
                                                                        <div class="more-menu-caret-outer"></div>
                                                                        <div class="more-menu-caret-inner"></div>
                                                                    </div>
                                                                    <ul class="more-menu-items" tabindex="-1" role="menu" aria-labelledby="more-btn" aria-hidden="true">
                                                                        <li class="more-menu-item" onclick="editGift('<?php echo $singleRow['Gift']['id']; ?>');" role="presentation">
                                                                            <button type="button" class="more-menu-btn" role="menuitem">Edit</button>
                                                                        </li>
                                                                        
                                                                        <?php
                                                                            if($singleRow['Gift']['featured']=="0")
                                                                            {
                                                                                ?>
                                                                                    <li class="more-menu-item" role="presentation">
                                                                                        <a href="process.php?action=featureGift&id=<?php echo $singleRow['Gift']['id']; ?>&featured=1">
                                                                                            <button type="button" class="more-menu-btn" role="menuitem">Feature</button>
                                                                                        </a>
                                                                                    </li>
                                                                                <?php
                                                                            }
                                                                            else
                                                                            {
                                                                                ?>
                                                                                    <li class="more-menu-item" role="presentation">
                                                                                        <a href="process.php?action=featureGift&id=<?php echo $singleRow['Gift']['id']; ?>&featured=0">
                                                                                            <button type="button" class="more-menu-btn" role="menuitem">Un Feature</button>
                                                                                        </a>
                                                                                    </li>
                                                                                <?php
                                                                            }
                                                                            
                                                                       ?>
                                                                        
                                                                        <li class="more-menu-item" role="presentation">
                                                                            <a href="process.php?action=deleteGift&id=<?php echo $singleRow['Gift']['id']; ?>">
                                                                                <button type="button" class="more-menu-btn" role="menuitem">Delete</button>
                                                                            </a>
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        
                                                        
                                                    </tr>
                                                <?php 
                                                
                                            endforeach; 
                                        }
                                        
                                        
                                    ?>

                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Image</th>
                                            <th>Sound</th>
                                            <th>Time</th>
                                            <th>Icon</th>
                                            <th>Coin</th>
                                            <th>Featured</th>
                                            <th>Created</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                </table>


                            </div>
                        </div>
                    </div>
                </div>

            </div>
        
            <script>
                $(document).ready(function () {
                    $('#table_view').DataTable({
                            "pageLength": 15
                        }
                    );
                });
            </script>
    <?php
    
       
} 
else 
{
	
	echo "<script>window.location='index.php'</script>";
    die;
    
} 

?>